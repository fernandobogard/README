package br.com.obdlivre.obd

import android.os.SystemClock
import java.nio.charset.StandardCharsets

/**
 * Um comando por vez. NUNCA use a instância em threads simultâneas:
 * a MainActivity serializa o acesso usando um único executor.
 */
class ElmClient(private val transport: ElmTransport) : AutoCloseable {
    /** Lê até o prompt '>' emitido pelo ELM327 (ou timeout). */
    fun command(cmd: String, timeoutMs: Long = 3500): String {
        require(cmd.all { it.code in 32..126 }) { "Comando inválido" }
        val output = transport.output
        // Evita misturar restos do prompt anterior com a resposta atual.
        while (transport.input.available() > 0) transport.input.read()
        output.write((cmd + "\r").toByteArray(StandardCharsets.US_ASCII))
        output.flush()
        val bytes = StringBuilder()
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        var prompt = false
        while (SystemClock.elapsedRealtime() < deadline) {
            if (transport.input.available() > 0) {
                val b = transport.input.read()
                if (b < 0) break
                if (b == '>'.code) { prompt = true; break }
                if (b in 9..126) bytes.append(b.toChar())
            } else Thread.sleep(15)
        }
        if (!prompt) throw IllegalStateException("Sem resposta completa do adaptador para '$cmd'")
        return bytes.toString().trim()
    }

    fun initialize(): String {
        val identity = command("ATZ", 5500)
        for (setting in listOf("ATE0", "ATL0", "ATS0", "ATH0", "ATSP0")) {
            val reply = command(setting)
            if (reply.contains("?")) throw IllegalStateException("ELM327 não aceitou $setting")
        }
        // 0100 provoca negociação do protocolo com a ECU; pode exigir alguns segundos.
        val supported = command("0100", 10000)
        if (ObdParser.pidBytes(supported, "00", 4) == null) {
            throw IllegalStateException("ELM conectado, mas não consegui detectar a ECU. Verifique ignição e compatibilidade. Resposta: $supported")
        }
        return identity.ifBlank { "ELM327" }
    }

    override fun close() = transport.close()
}
