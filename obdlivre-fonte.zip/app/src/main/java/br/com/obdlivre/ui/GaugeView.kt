package br.com.obdlivre.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import java.util.Locale
import kotlin.math.min

/** Mostrador independente, desenhado com Canvas. */
class GaugeView(context: Context, private val title: String, private val unit: String, private val maximum: Double) : View(context) {
    var reading: Double? = null
        set(value) { field = value; invalidate() }
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(219, 228, 234); style = Paint.Style.STROKE; strokeWidth = 14f; strokeCap = Paint.Cap.ROUND }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(16, 185, 129); style = Paint.Style.STROKE; strokeWidth = 14f; strokeCap = Paint.Cap.ROUND }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(85, 105, 122); textAlign = Paint.Align.CENTER; textSize = 32f }
    private val numberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(13, 40, 58); textAlign = Paint.Align.CENTER; textSize = 52f; isFakeBoldText = true }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(size, min((size * 0.89).toInt(), (resources.displayMetrics.density * 250).toInt()))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        val radius = min(w * 0.40f, h * 0.44f)
        val cx = w / 2; val cy = h * 0.53f
        val rect = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
        bg.strokeWidth = min(14f, radius * 0.13f)
        fg.strokeWidth = bg.strokeWidth
        canvas.drawArc(rect, 145f, 250f, false, bg)
        reading?.let { canvas.drawArc(rect, 145f, (250 * (it / maximum).coerceIn(0.0, 1.0)).toFloat(), false, fg) }
        numberPaint.textSize = (radius * 0.55f).coerceIn(24f, 56f)
        labelPaint.textSize = (radius * 0.26f).coerceIn(13f, 26f)
        val display = reading?.let { String.format(Locale.getDefault(), "%.0f", it) } ?: "--"
        canvas.drawText(display, cx, cy + numberPaint.textSize * 0.30f, numberPaint)
        canvas.drawText(unit, cx, cy + numberPaint.textSize * 0.30f + labelPaint.textSize * 1.2f, labelPaint)
        canvas.drawText(title, cx, h - 10f, labelPaint)
    }
}
