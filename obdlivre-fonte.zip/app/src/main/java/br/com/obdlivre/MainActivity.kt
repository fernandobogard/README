package br.com.obdlivre

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import br.com.obdlivre.obd.ClassicBluetoothTransport
import br.com.obdlivre.obd.ElmClient
import br.com.obdlivre.obd.ObdParser
import br.com.obdlivre.obd.WifiTransport
import br.com.obdlivre.ui.GaugeView
import br.com.obdlivre.ui.SensorGraphView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.sin

/**
 * OBD Livre 0.3: interface, conexão ELM327 SPP / TCP, telemetria, DTC e CSV.
 * NÃO contém bibliotecas, imagens nem código recuperado do aplicativo examinado.
 */
class MainActivity : Activity() {
    private val background = Executors.newSingleThreadScheduledExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pollTask: ScheduledFuture<*>? = null
    private var elm: ElmClient? = null  // Acessar apenas pela thread background.
    private var demo = false
    private var recording = false
    private var logFile: File? = null
    private var logForExport: File? = null
    private val devices = mutableListOf<BluetoothDevice>()
    // Todas as consultas são serializadas pelo executor, inclusive a descoberta de PIDs.
    private var supportedPids: Set<Int> = emptySet()
    private var lastTelemetry = Telemetry()
    private var secondaryCursor = 0
    private val secondaryPids = listOf(0x0B, 0x04, 0x0F, 0x11, 0x06, 0x07, 0x10, 0x2F, 0x42)
    private val chartHistory = linkedMapOf<String, ArrayDeque<Double>>()
    private var chartSelection = "RPM"

    private lateinit var status: TextView
    private lateinit var bluetoothDevices: Spinner
    private lateinit var ipEntry: EditText
    private lateinit var portEntry: EditText
    private lateinit var rpmGauge: GaugeView
    private lateinit var speedGauge: GaugeView
    private lateinit var tempGauge: GaugeView
    private lateinit var extraValues: TextView
    private lateinit var recordingButton: Button
    private lateinit var logStatus: TextView
    private lateinit var sensorsStatus: TextView
    private lateinit var graph: SensorGraphView

    private val navy = Color.rgb(16, 38, 58)
    private val green = Color.rgb(6, 139, 104)
    private val pale = Color.rgb(239, 245, 247)
    private val muted = Color.rgb(87, 110, 126)

    private data class Telemetry(
        val rpm: Double? = null, val speed: Double? = null, val coolant: Double? = null,
        val load: Double? = null, val air: Double? = null, val throttle: Double? = null,
        val battery: Double? = null, val map: Double? = null, val shortTrim: Double? = null,
        val longTrim: Double? = null, val maf: Double? = null, val fuel: Double? = null,
        val ecuVoltage: Double? = null
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
        reloadPairedDevices()
    }

    private fun dp(px: Int) = (px * resources.displayMetrics.density).toInt()
    private fun vertical() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun normal(text: String, size: Float = 15f, color: Int = navy): TextView =
        TextView(this).apply { this.text = text; textSize = size; setTextColor(color); setPadding(0, dp(5), 0, dp(5)) }
    private fun heading(text: String): TextView = normal(text, 19f).apply {
        setTypeface(null, Typeface.BOLD); setPadding(0, dp(8), 0, dp(12))
    }
    private fun button(text: String, color: Int = navy): Button = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(10).toFloat() }
        isAllCaps = false
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        lp.bottomMargin = dp(8); layoutParams = lp
    }
    private fun field(hint: String, value: String): EditText = EditText(this).apply {
        setSingleLine(true); setText(value); this.hint = hint; textSize = 15f
        setPadding(dp(10), dp(10), dp(10), dp(10))
        background = GradientDrawable().apply { setColor(pale); cornerRadius = dp(8).toFloat() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
        lp.bottomMargin = dp(9); layoutParams = lp
    }
    private fun card(parent: LinearLayout): LinearLayout {
        val inner = vertical()
        inner.setPadding(dp(16), dp(12), dp(16), dp(15))
        inner.background = GradientDrawable().apply {
            setColor(Color.WHITE); cornerRadius = dp(16).toFloat(); setStroke(dp(1), Color.rgb(219, 229, 234))
        }
        parent.addView(inner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(13)
        })
        return inner
    }

    private fun buildInterface() {
        val scroll = ScrollView(this).apply { setFillViewport(true); setBackgroundColor(pale) }
        val page = vertical().apply { setPadding(dp(16), dp(20), dp(16), dp(24)) }
        scroll.addView(page); setContentView(scroll)

        page.addView(normal("OBD LIVRE", 30f, navy).apply { setTypeface(null, Typeface.BOLD) })
        page.addView(normal("Diagnóstico automotivo • v0.3 • sensores inteligentes", 13f, muted))

        val connection = card(page)
        connection.addView(heading("Conectar ao veículo"))
        status = normal("Desconectado", 14f, muted)
        connection.addView(status)
        connection.addView(normal("Adaptadores Bluetooth já pareados:", 13f, muted))
        bluetoothDevices = Spinner(this)
        connection.addView(bluetoothDevices, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(47)))
        connection.addView(button("Atualizar dispositivos pareados").apply { setOnClickListener { reloadPairedDevices() } })
        connection.addView(button("Conectar via Bluetooth", green).apply { setOnClickListener { connectBluetooth() } })
        connection.addView(normal("Ou usar um ELM327 Wi-Fi (IP / porta):", 13f, muted))
        ipEntry = field("IP do adaptador", "192.168.0.10")
        portEntry = field("Porta TCP", "35000").apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        connection.addView(ipEntry); connection.addView(portEntry)
        connection.addView(button("Conectar via Wi-Fi", green).apply { setOnClickListener { connectWifi() } })
        connection.addView(button("Testar painel sem veículo", Color.rgb(44, 99, 150)).apply { setOnClickListener { startDemo() } })
        connection.addView(button("Procurar sensores da ECU").apply { setOnClickListener { reScanCapabilities() } })
        connection.addView(button("Desconectar", muted).apply { setOnClickListener { disconnect() } })

        val dash = card(page)
        dash.addView(heading("Painel em tempo real"))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rpmGauge = GaugeView(this, "Motor", "rpm", 8000.0)
        speedGauge = GaugeView(this, "Velocidade", "km/h", 240.0)
        row.addView(rpmGauge, LinearLayout.LayoutParams(0, dp(163), 1f))
        row.addView(speedGauge, LinearLayout.LayoutParams(0, dp(163), 1f))
        dash.addView(row)
        tempGauge = GaugeView(this, "Arrefecimento", "°C", 130.0)
        val single = LinearLayout(this).apply { gravity = Gravity.CENTER }
        single.addView(tempGauge, LinearLayout.LayoutParams(dp(173), dp(155)))
        dash.addView(single)
        val sensorCard = card(page)
        sensorCard.addView(heading("Sensores disponíveis na ECU"))
        sensorsStatus = normal("Aguardando conexão para identificar os PIDs disponíveis.", 13f, muted)
        sensorCard.addView(sensorsStatus)
        sensorCard.addView(normal("Parâmetros adicionais (quando suportados):", 13f, muted))
        extraValues = normal("Conecte o veículo para consultar os sensores.", 14f)
        sensorCard.addView(extraValues)
        sensorCard.addView(normal("-- significa sensor não suportado ou sem resposta válida; a tensão do ELM é uma leitura do adaptador.", 12f, muted))

        val graphCard = card(page)
        graphCard.addView(heading("Gráfico de leituras recentes"))
        val graphOptions = listOf("RPM", "Temperatura", "MAP", "Borboleta")
        val selectGraph = Spinner(this)
        selectGraph.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, graphOptions)
        graphCard.addView(selectGraph, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)))
        graph = SensorGraphView(this)
        graphCard.addView(graph, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(185)))
        selectGraph.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) { }
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                chartSelection = graphOptions[position]
                renderChart()
            }
        }

        val tools = card(page)
        tools.addView(heading("Diagnóstico e ferramentas"))
        tools.addView(button("Ler códigos de falha (DTC)").apply { setOnClickListener { readErrors() } })
        tools.addView(button("Apagar falhas — exige confirmação", Color.rgb(172, 70, 43)).apply {
            setOnClickListener { confirmClearErrors() }
        })
        recordingButton = button("Iniciar registro CSV", green).apply { setOnClickListener { toggleRecording() } }
        tools.addView(recordingButton)
        logStatus = normal("Nenhum registro iniciado", 13f, muted)
        tools.addView(logStatus)
        tools.addView(button("Exportar último registro CSV").apply { setOnClickListener { exportLog() } })
        tools.addView(normal("Utilize o app apenas com o veículo estacionado. Recursos de programação de módulos não estão habilitados nesta versão.", 12f, muted))
    }

    private fun post(action: () -> Unit) = mainHandler.post { if (!isFinishing) action() }
    private fun showStatus(message: String) = post { status.text = message }
    private fun inform(title: String, message: String) = post {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show()
    }
    private fun bluetoothAdapter(): BluetoothAdapter? =
        (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private fun bluetoothPermission(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) return true
        requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 100)
        return false
    }

    @Suppress("DEPRECATION")
    private fun reloadPairedDevices() {
        if (!bluetoothPermission()) return
        val adapter = bluetoothAdapter()
        devices.clear()
        if (adapter?.isEnabled == true) {
            try { devices.addAll(adapter.bondedDevices.sortedBy { it.name ?: "" }) }
            catch (e: SecurityException) { showStatus("Sem permissão Bluetooth: ${e.message}") }
        }
        val names = if (devices.isEmpty()) listOf("Nenhum dispositivo pareado; ative o Bluetooth nas configurações")
        else devices.map { "${it.name ?: "Sem nome"} • ${it.address}" }
        bluetoothDevices.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
    }

    @Suppress("DEPRECATION")
    private fun connectBluetooth() {
        if (!bluetoothPermission()) return
        val adapter = bluetoothAdapter()
        if (adapter?.isEnabled != true) {
            inform("Bluetooth desativado", "Ative o Bluetooth nas configurações do Android e pareie o ELM327 antes de conectar.")
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            return
        }
        val dev = devices.getOrNull(bluetoothDevices.selectedItemPosition)
        if (dev == null) { inform("Nenhum dispositivo", "Pareie o ELM327 nas configurações Bluetooth e toque em Atualizar."); return }
        beginConnection { ClassicBluetoothTransport(dev) }
    }

    private fun connectWifi() {
        val host = ipEntry.text.toString().trim()
        val port = portEntry.text.toString().toIntOrNull()
        if (host.isBlank() || port == null || port !in 1..65535) {
            inform("Endereço inválido", "Informe IP e porta TCP válidos do adaptador.")
            return
        }
        beginConnection { WifiTransport(host, port) }
    }

    private fun beginConnection(open: () -> br.com.obdlivre.obd.ElmTransport) {
        stopPolling()
        demo = false
        showStatus("Conectando e negociando protocolo OBD2…")
        background.execute {
            try {
                elm?.close(); elm = null
                val candidate = ElmClient(open())
                try {
                    val identity = candidate.initialize()
                    elm = candidate
                    lastTelemetry = Telemetry()
                    secondaryCursor = 0
                    post { chartHistory.clear(); renderChart() }
                    showStatus("Conectado • $identity • procurando sensores…")
                    scanCapabilities(candidate)
                    showStatus("Conectado • $identity • sensores identificados")
                    startPolling()
                } catch (e: Exception) { candidate.close(); throw e }
            } catch (e: Exception) {
                showStatus("Não conectado: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun scanCapabilities(client: ElmClient) {
        // 0100 sempre foi verificado no handshake; 0120/0140 só quando anunciados.
        val first = ObdParser.supportedPids(client.command("0100", 7000), 0)
            ?: throw IllegalStateException("A ECU não respondeu à lista de PIDs 0100")
        val detected = first.toMutableSet()
        for (page in listOf(0x20, 0x40, 0x60)) {
            if (page !in detected) break
            try {
                val reply = client.command(String.format(Locale.US, "01%02X", page), 6000)
                detected.addAll(ObdParser.supportedPids(reply, page) ?: break)
            } catch (_: Exception) { break }
        }
        supportedPids = detected
        val target = listOf(
            0x0C to "RPM", 0x0D to "Velocidade", 0x05 to "Arrefecimento",
            0x0B to "MAP", 0x04 to "Carga", 0x0F to "Ar admissão",
            0x11 to "Borboleta", 0x06 to "STFT B1", 0x07 to "LTFT B1",
            0x10 to "MAF", 0x2F to "Combustível", 0x42 to "Tensão ECU"
        )
        val identified = target.filter { it.first in detected }.joinToString(", ") { it.second }
        post {
            sensorsStatus.text = "${detected.size} PIDs anunciados pela ECU. Leituras reconhecidas: " +
                identified.ifBlank { "nenhuma desta lista" } +
                "\nPID hexadecimal: " + detected.sorted().joinToString(" ") { "%02X".format(Locale.US, it) }
        }
    }

    private fun reScanCapabilities() {
        if (demo) { inform("Modo demonstração", "Conecte um veículo para pesquisar os sensores disponíveis."); return }
        stopPolling()
        background.execute {
            val client = elm
            if (client == null) { inform("Sem conexão", "Conecte o ELM327 primeiro."); return@execute }
            showStatus("Consultando sensores disponíveis…")
            try {
                scanCapabilities(client)
                lastTelemetry = Telemetry()
                secondaryCursor = 0
                showStatus("Sensores identificados; leituras reiniciadas")
            } catch (e: Exception) {
                showStatus("Não foi possível atualizar a lista: ${e.message}")
            } finally { if (elm === client) startPolling() }
        }
    }

    private fun startPolling() {
        stopPolling()
        pollTask = background.scheduleWithFixedDelay({
            try {
                val data = if (demo) demoData() else readTelemetry(elm ?: return@scheduleWithFixedDelay)
                post { updateDashboard(data) }
                if (recording) saveLine(data)
            } catch (e: Exception) {
                stopPolling()
                showStatus("Leitura interrompida: ${e.message ?: "Erro de comunicação"}")
            }
        }, 0, 850, TimeUnit.MILLISECONDS)
    }

    private fun stopPolling() {
        pollTask?.cancel(false)
        pollTask = null
    }

    private fun readTelemetry(client: ElmClient): Telemetry {
        // No ELM327 as consultas são sequenciais. Lemos os 3 mostradores em cada
        // rodada e distribuímos os sensores restantes por até 3 consultas/rodada.
        fun read(pid: Int, parser: (String) -> Double?): Double? {
            if (pid !in supportedPids) return null
            return try {
                parser(client.command("01%02X".format(Locale.US, pid)))
            } catch (e: Exception) {
                // Um PID opcional lento não deve interromper o painel principal.
                if (pid in setOf(0x0C, 0x0D, 0x05)) throw e
                null
            }
        }
        var data = lastTelemetry.copy(
            rpm = read(0x0C, ObdParser::rpm),
            speed = read(0x0D, ObdParser::speed),
            coolant = read(0x05, ObdParser::coolant)
        )
        val extras = secondaryPids.filter { it in supportedPids }
        if (extras.isNotEmpty()) {
            repeat(minOf(3, extras.size)) {
                val pid = extras[secondaryCursor % extras.size]
                secondaryCursor++
                data = when (pid) {
                    0x0B -> data.copy(map = read(pid, ObdParser::manifoldPressure))
                    0x04 -> data.copy(load = read(pid, ObdParser::engineLoad))
                    0x0F -> data.copy(air = read(pid, ObdParser::intakeTemp))
                    0x11 -> data.copy(throttle = read(pid, ObdParser::throttle))
                    0x06 -> data.copy(shortTrim = read(pid, ObdParser::shortFuelTrim))
                    0x07 -> data.copy(longTrim = read(pid, ObdParser::longFuelTrim))
                    0x10 -> data.copy(maf = read(pid, ObdParser::maf))
                    0x2F -> data.copy(fuel = read(pid, ObdParser::fuelLevel))
                    0x42 -> data.copy(ecuVoltage = read(pid, ObdParser::ecuVoltage))
                    else -> data
                }
            }
        }
        // ATRV mede a alimentação do adaptador, não uma medição exata da bateria.
        if (secondaryCursor % 12 < 3) {
            try { data = data.copy(battery = ObdParser.voltage(client.command("ATRV"))) }
            catch (_: Exception) { /* A tensão do adaptador é opcional. */ }
        }
        lastTelemetry = data
        return data
    }

    private fun demoData(): Telemetry {
        val t = System.currentTimeMillis() / 1000.0
        return Telemetry(rpm = 1900.0 + 950 * sin(t / 3), speed = 55.0 + 24 * sin(t / 5),
            coolant = 88.0 + 4 * sin(t / 25), load = 35.0 + 18 * sin(t / 3),
            air = 31.0 + 3 * sin(t / 20), throttle = 24.0 + 15 * sin(t / 3),
            battery = 13.8, map = 45.0 + 22 * sin(t / 7),
            shortTrim = 3 * sin(t / 12), longTrim = -1.6,
            maf = 14 + 6 * sin(t / 4), fuel = 50.0, ecuVoltage = 13.9)
    }

    private fun fmt(n: Double?, digits: Int = 0): String =
        n?.let { String.format(Locale.getDefault(), "%1$.${digits}f", it) } ?: "--"

    private fun updateDashboard(data: Telemetry) {
        rpmGauge.reading = data.rpm
        speedGauge.reading = data.speed
        tempGauge.reading = data.coolant
        extraValues.text = "MAP: ${fmt(data.map)} kPa\n" +
            "Carga calculada: ${fmt(data.load)} %\n" +
            "Ar de admissão: ${fmt(data.air)} °C\n" +
            "Borboleta: ${fmt(data.throttle)} %\n" +
            "Correção curta (STFT B1): ${fmt(data.shortTrim, 1)} %\n" +
            "Correção longa (LTFT B1): ${fmt(data.longTrim, 1)} %\n" +
            "Fluxo de ar (MAF): ${fmt(data.maf, 1)} g/s\n" +
            "Nível de combustível (PID): ${fmt(data.fuel)} %\n" +
            "Tensão da ECU: ${fmt(data.ecuVoltage, 2)} V\n" +
            "Tensão no ELM327: ${fmt(data.battery, 2)} V"
        for ((name, value) in listOf(
            "RPM" to data.rpm, "Temperatura" to data.coolant,
            "MAP" to data.map, "Borboleta" to data.throttle
        )) {
            if (value != null) {
                val series = chartHistory.getOrPut(name) { ArrayDeque() }
                series.addLast(value)
                if (series.size > 55) series.removeFirst()
            }
        }
        renderChart()
    }

    private fun renderChart() {
        if (!::graph.isInitialized) return
        val label = when (chartSelection) {
            "RPM" -> "RPM"
            "Temperatura" -> "°C"
            "MAP" -> "kPa"
            else -> "%"
        }
        graph.showSeries(chartSelection, label, chartHistory[chartSelection]?.toList() ?: emptyList())
    }

    private fun startDemo() {
        stopPolling()
        background.execute { elm?.close(); elm = null }
        demo = true
        post { sensorsStatus.text = "Modo demonstração: todos os valores são simulados, não são leituras do veículo."; chartHistory.clear() }
        showStatus("MODO DEMONSTRAÇÃO • dados simulados")
        startPolling()
    }

    private fun disconnect() {
        stopPolling()
        demo = false
        background.execute { elm?.close(); elm = null; supportedPids = emptySet(); lastTelemetry = Telemetry() }
        post { sensorsStatus.text = "Desconectado. Conecte o veículo para identificar PIDs." }
        showStatus("Desconectado")
    }

    private fun readErrors() {
        if (demo) { inform("Modo demonstração", "Os códigos de falha só podem ser lidos com uma ECU conectada."); return }
        background.execute {
            val session = elm
            if (session == null) { inform("Sem conexão", "Conecte o veículo antes de ler códigos de falha."); return@execute }
            try {
                val response = session.command("03", 7000)
                if (response.contains("NO DATA", true)) {
                    inform("DTC", "A ECU respondeu NO DATA. Não há códigos retornados nesse modo, ou o serviço não é suportado.")
                } else {
                    val codes = ObdParser.dtcs(response)
                    inform("Códigos de falha", if (codes.isNotEmpty()) codes.joinToString("\n")
                    else if (response.replace(Regex("\\s+"), "").uppercase(Locale.US).contains("4300"))
                        "A ECU retornou 43 00, sem DTC padronizado decodificável. Resposta: $response"
                    else "Nenhum código decodificável encontrado. Resposta bruta:\n$response\n\nRespostas ISO-TP complexas exigirão um decodificador ampliado.")
                }
            } catch (e: Exception) { inform("Erro ao ler DTC", e.message ?: "Erro na comunicação") }
        }
    }

    private fun confirmClearErrors() {
        if (demo) { inform("Modo demonstração", "Não é possível apagar falhas no modo de demonstração."); return }
        AlertDialog.Builder(this).setTitle("Apagar códigos de falha?")
            .setMessage("O comando OBD2 serviço 04 pode apagar DTCs, dados congelados (freeze frame) e reiniciar monitores de emissões. Somente com o veículo parado e com autorização do proprietário. Deseja continuar?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Confirmar") { _, _ ->
                background.execute {
                    val session = elm
                    if (session == null) { inform("Sem conexão", "Conecte o veículo primeiro."); return@execute }
                    try {
                        val reply = session.command("04", 7000)
                        inform("Resposta da ECU", if (Regex("(?:^|\\s)44(?:\\s|$)").containsMatchIn(reply))
                            "A ECU confirmou o serviço 04. Verifique a condição dos monitores de emissões."
                        else "Não houve confirmação conclusiva de apagamento. Resposta: $reply")
                    } catch (e: Exception) { inform("Erro", e.message ?: "Falha na comunicação") }
                }
            }.show()
    }

    private fun toggleRecording() {
        if (!recording) {
            if (!demo && elm == null) { inform("Sem dados", "Conecte um veículo ou use o modo demonstração."); return }
            val folder = File(filesDir, "logs").apply { mkdirs() }
            val name = "obd_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.csv"
            val file = File(folder, name)
            file.writeText("timestamp_iso,rpm,velocidade_kmh,temperatura_c,carga_pct,ar_c,borboleta_pct,tensao_elm_v,map_kpa,stft_pct,ltft_pct,maf_g_s,combustivel_pct,tensao_ecu_v\n")
            logFile = file; logForExport = file; recording = true
            recordingButton.text = "Parar registro CSV"
            logStatus.text = "Gravando: $name"
        } else {
            recording = false
            recordingButton.text = "Iniciar registro CSV"
            logStatus.text = "Registro encerrado: ${logFile?.name}"
        }
    }

    private fun saveLine(data: Telemetry) {
        val file = logFile ?: return
        fun csv(v: Double?) = v?.let { String.format(Locale.US, "%.2f", it) } ?: ""
        val time = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US).format(Date())
        val fields = listOf(time, csv(data.rpm), csv(data.speed), csv(data.coolant), csv(data.load), csv(data.air), csv(data.throttle), csv(data.battery), csv(data.map), csv(data.shortTrim), csv(data.longTrim), csv(data.maf), csv(data.fuel), csv(data.ecuVoltage))
        try { file.appendText(fields.joinToString(",") + "\n") }
        catch (e: Exception) { recording = false; inform("Falha na gravação", e.message ?: "Não foi possível escrever CSV") }
    }

    @Suppress("DEPRECATION")
    private fun exportLog() {
        val file = logForExport
        if (file == null || !file.exists()) { inform("Sem registro", "Inicie e finalize uma gravação para exportar."); return }
        if (recording) { inform("Registro em andamento", "Pare a gravação antes de exportar o arquivo."); return }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, file.name)
        }
        try { startActivityForResult(intent, 301) }
        catch (e: Exception) { inform("Exportação indisponível", e.message ?: "Nenhum gerenciador de arquivos disponível") }
    }

    @Deprecated("Compatibilidade API Android: Storage Access Framework sem dependências externas")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 301 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val file = logForExport ?: return
            try {
                contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } }
                    ?: throw IllegalStateException("Não foi possível abrir o arquivo de destino")
                Toast.makeText(this, "CSV exportado", Toast.LENGTH_LONG).show()
            } catch (e: Exception) { inform("Falha ao exportar", e.message ?: "Erro desconhecido") }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) reloadPairedDevices()
    }

    override fun onDestroy() {
        stopPolling(); recording = false
        try { elm?.close() } catch (_: Exception) {}
        background.shutdownNow()
        super.onDestroy()
    }
}
