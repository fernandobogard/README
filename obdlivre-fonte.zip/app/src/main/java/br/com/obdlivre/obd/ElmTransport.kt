package br.com.obdlivre.obd

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID

/**
 * Transporte de bytes, independente do protocolo de diagnóstico.
 * A conexão acontece numa thread de trabalho, nunca na thread de interface.
 */
interface ElmTransport : AutoCloseable {
    val input: InputStream
    val output: OutputStream
}

class ClassicBluetoothTransport(device: BluetoothDevice) : ElmTransport {
    // UUID do Serial Port Profile (SPP) dos ELM327 Bluetooth clássicos.
    private val socket: BluetoothSocket = device.createRfcommSocketToServiceRecord(
        UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    ).also { it.connect() }
    override val input: InputStream get() = socket.inputStream
    override val output: OutputStream get() = socket.outputStream
    override fun close() = socket.close()
}

class WifiTransport(ip: String, port: Int) : ElmTransport {
    private val socket = Socket().apply {
        connect(InetSocketAddress(ip, port), 5000)
        soTimeout = 4000
        tcpNoDelay = true
    }
    override val input: InputStream get() = socket.getInputStream()
    override val output: OutputStream get() = socket.getOutputStream()
    override fun close() = socket.close()
}
