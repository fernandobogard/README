package br.com.obdlivre.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Gráfico leve para as últimas amostras do sensor escolhido.
 * Não usa rede, permissões extras nem bibliotecas de terceiros.
 */
class SensorGraphView(context: Context) : View(context) {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(6, 139, 104)
        strokeWidth = 3f * resources.displayMetrics.density
        strokeJoin = Paint.Join.ROUND
        style = Paint.Style.STROKE
    }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(225, 234, 237)
        strokeWidth = resources.displayMetrics.density
        style = Paint.Style.STROKE
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(87, 110, 126)
        textSize = 12f * resources.displayMetrics.scaledDensity
    }
    private var title: String = "RPM"
    private var unit: String = "RPM"
    private var values: List<Double> = emptyList()

    fun showSeries(sensor: String, sensorUnit: String, samples: List<Double>) {
        title = sensor
        unit = sensorUnit
        values = samples
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val density = resources.displayMetrics.density
        val x0 = 55f * density
        val right = width.toFloat() - 12 * density
        val top = 25f * density
        val bottom = height.toFloat() - 27 * density
        if (right <= x0 || bottom <= top) return
        canvas.drawText("$title ($unit)", x0, 17f * density, label)
        if (values.isEmpty()) {
            canvas.drawText("Aguardando leituras válidas...", x0, (top + bottom) / 2, label)
            return
        }
        val minimum = values.minOrNull() ?: 0.0
        val maximum = values.maxOrNull() ?: 0.0
        val padding = max((maximum - minimum) * 0.15, max(maximum * 0.05, 1.0))
        val low = minimum - padding
        val high = maximum + padding
        for (i in 0..3) {
            val y = top + (bottom - top) * i / 3f
            canvas.drawLine(x0, y, right, y, grid)
            val v = high - (high - low) * i / 3.0
            canvas.drawText(String.format(Locale.getDefault(), "%.0f", v), 3f * density, y + 4 * density, label)
        }
        val path = Path()
        for ((index, value) in values.withIndex()) {
            val fraction = if (values.size == 1) 1f else index.toFloat() / (values.size - 1)
            val x = x0 + (right - x0) * fraction
            val y = bottom - ((value - low) / (high - low) * (bottom - top)).toFloat()
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, line)
        canvas.drawText("${values.size} amostras • última: ${String.format(Locale.getDefault(), "%.1f", values.last())}", x0, height - 7f * density, label)
    }
}
