package br.com.obdlivre.obd

import java.util.Locale

/**
 * Interpretação de respostas ELM327 e de PIDs genéricos do SAE J1979.
 * Compatibilidade de PIDs varia conforme o automóvel/ECU.
 */
object ObdParser {
    /** Procura o payload 41 + PID em respostas com ou sem espaços e prefixos de ECU. */
    fun pidBytes(raw: String, pid: String, count: Int): List<Int>? {
        val pidHex = pid.uppercase(Locale.US)
        val pattern = Regex("41\\s*$pidHex((?:\\s*[0-9A-F]{2}){$count})")
        for (line in raw.uppercase(Locale.US).replace("\r", "\n").lines()) {
            val match = pattern.find(line) ?: continue
            return Regex("[0-9A-F]{2}").findAll(match.groupValues[1])
                .map { it.value.toInt(16) }.toList().takeIf { it.size == count }
        }
        return null
    }

    fun rpm(raw: String): Double? = pidBytes(raw, "0C", 2)?.let { (a, b) -> (a * 256 + b) / 4.0 }
    fun speed(raw: String): Double? = pidBytes(raw, "0D", 1)?.first()?.toDouble()
    fun coolant(raw: String): Double? = pidBytes(raw, "05", 1)?.first()?.minus(40)?.toDouble()
    fun engineLoad(raw: String): Double? = pidBytes(raw, "04", 1)?.first()?.let { it * 100.0 / 255.0 }
    fun intakeTemp(raw: String): Double? = pidBytes(raw, "0F", 1)?.first()?.minus(40)?.toDouble()
    fun throttle(raw: String): Double? = pidBytes(raw, "11", 1)?.first()?.let { it * 100.0 / 255.0 }

    fun voltage(raw: String): Double? = Regex("([0-9]+(?:\\.[0-9]+)?)\\s*V", RegexOption.IGNORE_CASE)
        .find(raw)?.groupValues?.getOrNull(1)?.toDoubleOrNull()

    /**
     * Decodifica respostas comuns do serviço 03 (MIL/DTC). Não resolve ainda
     * o reagrupamento ISO-TP multiframes nem todos os layouts de fabricante.
     */
    fun dtcs(raw: String): List<String> {
        val codes = linkedSetOf<String>()
        for (line in raw.uppercase(Locale.US).replace("\r", "\n").lines()) {
            // O modo 03 respondido pela ECU inicia com byte 43.
            val clean = line.replace(" ", "")
            val start = Regex("43(?:[0-9A-F]{4})+").find(clean)?.value ?: continue
            val pairs = start.drop(2).chunked(4)
            for (pair in pairs) {
                if (pair.length != 4 || pair == "0000") continue
                val v = pair.toIntOrNull(16) ?: continue
                val system = "PCBU"[(v shr 14) and 3]
                val firstDigit = (v shr 12) and 3
                val suffix = (v and 0x0FFF).toString(16).uppercase(Locale.US).padStart(3, '0')
                codes.add("$system$firstDigit$suffix")
            }
        }
        return codes.toList()
    }
}
