package br.com.obdlivre.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ObdParserTest {
    @Test fun rpmWithSpaces() = assertEquals(1726.0, ObdParser.rpm("41 0C 1A F8\r>" )!!, 0.001)
    @Test fun rpmCompactAndHeader() = assertEquals(1726.0, ObdParser.rpm("7E8 04 410C1AF8" )!!, 0.001)
    @Test fun speed() = assertEquals(40.0, ObdParser.speed("41 0D 28" )!!, 0.001)
    @Test fun coolant() = assertEquals(80.0, ObdParser.coolant("410578")!!, 0.001)
    @Test fun noData() = assertNull(ObdParser.speed("NO DATA"))
    @Test fun dtcs() = assertEquals(listOf("P0133"), ObdParser.dtcs("43 01 33 00 00"))
    @Test fun bitmapSupport() {
        // Máscara para 01, 05, 0C, 0D e 20.
        val expected = setOf(0x01, 0x05, 0x0C, 0x0D, 0x20)
        val bytes = IntArray(4)
        for (pid in expected) {
            val bit = pid - 1
            bytes[bit / 8] = bytes[bit / 8] or (0x80 ushr (bit % 8))
        }
        val reply = "41 00 " + bytes.joinToString(" ") { "%02X".format(it) }
        assertEquals(expected, ObdParser.supportedPids(reply, 0))
        assertNull(ObdParser.supportedPids("NO DATA", 0))
        assertEquals(setOf(0x2F), ObdParser.supportedPids("41 20 00 02 00 00", 0x20))
    }
    @Test fun extraSensorConversions() {
        assertEquals(82.0, ObdParser.manifoldPressure("41 0B 52")!!, 0.001)
        assertEquals(0.0, ObdParser.shortFuelTrim("410680")!!, 0.001)
        assertEquals(25.0, ObdParser.shortFuelTrim("4106A0")!!, 0.001)
        assertEquals(16.0, ObdParser.maf("41100640")!!, 0.001)
        assertEquals(13.8, ObdParser.ecuVoltage("414235E8")!!, 0.001)
    }
    @Test fun voltage() = assertEquals(13.7, ObdParser.voltage("13.7V")!!, 0.001)
}
