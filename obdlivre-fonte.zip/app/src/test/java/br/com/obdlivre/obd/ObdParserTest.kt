package br.com.obdlivre.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ObdParserTest {
    @Test fun rpmWithSpaces() = assertEquals(1726.0, ObdParser.rpm("41 0C 1A F8\r>" )!!, 0.001)
    @Test fun rpmCompactAndHeader() = assertEquals(1726.0, ObdParser.rpm("7E8 04 410C1AF8" )!!, 0.001)
    @Test fun speed() = assertEquals(40.0, ObdParser.speed("41 0D 28" )!!, 0.001)
    @Test fun coolant() = assertEquals(80.0, ObdParser.coolant("410578")!!, 0.001)
    @Test fun noData() = assertNull(ObdParser.speed("NO DATA"))
    @Test fun dtcs() = assertEquals(listOf("P0133"), ObdParser.dtcs("43 01 33 00 00"))
    @Test fun voltage() = assertEquals(13.7, ObdParser.voltage("13.7V")!!, 0.001)
}
