# OBD Livre v0.3 — sensores automáticos (teste)

Este projeto é uma alternativa independente e experimental para diagnóstico OBD2 em Android. Foi desenvolvido do zero em Kotlin, usando protocolos OBD2 padronizados. Não reutiliza componentes de aplicativos comerciais.

## Melhorias em relação à 0.1

- Consulta automática dos blocos PID `0100`, `0120`, `0140` e `0160` quando a ECU anunciar suporte a eles.
- Identifica quais PIDs a ECU anuncia e apresenta lista hexadecimal e nomes reconhecidos.
- Mantém RPM (010C), velocidade (010D) e temperatura do arrefecimento (0105).
- Inclui consultas condicionais a MAP (010B), carga calculada (0104), temperatura do ar (010F), borboleta (0111), STFT/LTFT do banco 1 (0106/0107), fluxo MAF (0110), nível de combustível (012F), tensão da ECU (0142), além da tensão do adaptador (ATRV).
- Consulta até três sensores opcionais por rodada para não atrasar demasiadamente os mostradores principais.
- Gráfico de últimas 55 amostras para RPM, temperatura, MAP ou posição da borboleta; muda pelo seletor.
- Exportação CSV com novas colunas e explicação para resposta DTC `43 00`.
- Botão **Procurar sensores da ECU** para refazer a varredura sem precisar reinstalar.

## Limitações e boas práticas

- O padrão OBD2 **não garante** que seu veículo suporte todos esses PIDs: sensores indisponíveis aparecem como `--`.
- O scanner pode anunciar suporte e ainda assim responder sem dados válidos; nesses casos o aplicativo mantém `--`.
- O MAP é pressão absoluta no coletor em **kPa**. Correções STFT/LTFT são percentuais do banco 1.
- ATRV é tensão no adaptador ELM327, não aferição direta do estado da bateria.
- As medições podem variar em frequência porque o ELM327 responde sequencialmente e pode ser lento.
- O gráfico contém as leituras recebidas nesta sessão, não é armazenado entre fechamentos do app.
- Não implementa PIDs proprietários Volkswagen, UDS, codificação de módulos, ABS ou airbag.
- Apagar DTCs (serviço 04) exige confirmação e altera dados da ECU. Evite usar essa função durante os testes.
- Teste apenas com o veículo parado; não mexa no celular dirigindo.

## Compilação no GitHub sem Android Studio

No repositório `README` usado anteriormente, mantenha o arquivo `.github/workflows/gerar-apk.yml` da **versão 3**. Envie o ZIP `obdlivre-fonte.zip` à raiz do repositório substituindo o arquivo anterior. Ao confirmar o commit, abra **Actions** e aguarde a compilação. Em caso de sucesso, baixe o artefato `OBDLivre-APK-debug`.

**IMPORTANTE sobre atualização de APK de depuração:** cada execução em uma máquina nova do GitHub Actions pode assinar o APK com uma nova chave de teste. Se o Android disser "não foi possível atualizar" ou "assinatura diferente", exporte antes quaisquer registros CSV antigos e desinstale a versão anterior, então instale a v0.3. Para atualizações regulares sem reinstalação, será necessário adotar uma chave de assinatura estável protegida por secrets do GitHub.

## Validação

- Os decodificadores PIDs novos e antigos foram compilados e validados localmente com amostras de respostas OBD2.
- A compilação completa Android da v0.3 **ainda não foi verificada**: é realizada no GitHub Actions após seu commit.
- A coleta real no VW Gol G6 1.0 2013 também deve ser testada por você; na v0.1 RPM, velocidade e temperatura já foram observados em tempo real.
