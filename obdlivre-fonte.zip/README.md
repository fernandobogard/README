# OBD Livre — protótipo Android 0.1

Projeto **original e independente** de diagnóstico automotivo via OBD2/ELM327. A proposta de longo prazo é criar uma alternativa abrangente, com funcionalidades similares (não código/identidade copiados) às dos aplicativos comerciais do segmento.

## Implementado neste código

- Android nativo em **Kotlin**, sem bibliotecas externas de interface;
- acesso a dispositivos **Bluetooth clássico SPP já pareados**;
- conexão **Wi-Fi/TCP** a adaptadores ELM327 com IP/porta configuráveis;
- inicialização ELM327 (ATZ, ATE0, ATL0, ATS0, ATH0, ATSP0) e teste de comunicação 0100;
- leitura em tempo real de RPM, velocidade, temperatura do motor, carga, temperatura do ar, borboleta, tensão reportada pelo adaptador;
- painel com mostradores desenhados nativamente;
- leitura de DTCs genéricos modo 03 (**somente casos comuns de resposta simples**);
- limpeza de DTCs pelo serviço 04 **com confirmação**;
- registro de dados em CSV local e exportação pela interface de arquivos Android;
- demonstração com sensores simulados, útil sem adaptador;
- testes básicos do parser com JUnit.

## Ainda NÃO implementado

Bluetooth BLE, USB, protocolos de fabricantes e suas bibliotecas de PIDs, reagrupamento robusto ISO-TP CAN, UDS, VIN completo, readiness, freeze frame, testes de emissões, HUD, aceleração, mapas/rotas e consumo, dashboards totalmente editáveis, gráficos históricos, sincronização, perfis de veículos e personalização profunda. **Não é alternativa completa ainda**: é o primeiro módulo funcional em código, sem validação em veículo.

## Como abrir

1. Instale **Android Studio** com JDK 17 e Android SDK Platform 35.
2. Abra a pasta `OBDLivre_Android` e permita sincronizar o Gradle. O Android Studio deverá obter o plugin Android `8.7.3`, Kotlin `1.9.25` e Gradle `8.9`.
3. Caso o projeto não encontre um Gradle Wrapper, configure o Gradle 8.9 em Settings > Build Tools > Gradle e depois gere o wrapper com `gradle wrapper --gradle-version 8.9`. O ZIP inclui `gradle/wrapper/gradle-wrapper.properties`, mas **não inclui `gradle-wrapper.jar`**.
4. Construa e instale o APK (Build > Build APK(s)) no telefone.
5. Para ELM327 Bluetooth clássico: pareie primeiro em **Configurações > Bluetooth** no Android, ligue a ignição, escolha o dispositivo pareado no app e conecte.
6. Para ELM327 Wi-Fi: conecte o celular à rede do adaptador, insira IP/porta da documentação do dispositivo e conecte.
7. Use **Testar painel sem veículo** para experimentar sem hardware.

## Pontos para testar/ajustar no carro

- Testar diferentes clones ELM327: alguns rejeitam comandos, são muito lentos ou têm firmware incompleto.
- Testar o tempo de resposta ao conectar e consultar `0100` e sete PIDs.
- Confirmar decodificação de DTCs com respostas multiframes reais antes de depender dela para manutenção.
- Nunca operar o painel ou o diagnóstico dirigindo. Evitar comandos de apagamento sem compreender que podem afetar dados de manutenção/emissões.
- O comando `ATRV` mostra **a tensão medida no adaptador**, que pode não coincidir com uma medição direta da bateria.
- Não conectar nem instalar dispositivos OBD durante a condução.

## Organização

- `app/src/main/java/br/com/obdlivre/obd/ElmTransport.kt`: interfaces Bluetooth SPP e Wi-Fi.
- `.../obd/ElmClient.kt`: AT, troca de mensagens, prompt e inicialização.
- `.../obd/ObdParser.kt`: conversão dos PIDs e DTCs simples.
- `.../ui/GaugeView.kt`: mostradores circulares.
- `.../MainActivity.kt`: interface, testes de conexão, leitura, registro e exportação.
- `app/src/test/.../ObdParserTest.kt`: testes automatizados do parser.

## Limitações da entrega

Esta pasta é **código-fonte para Android Studio**, **não um APK compilado**. No ambiente de geração não há instalação local de Android SDK/Gradle, nem um ELM327/veículo real conectado. Portanto, não há comprovação de compilação em Android Studio nem de funcionamento com um veículo: os testes finais devem ser feitos em um computador com o SDK e no hardware correspondente.

## Licença / autoria

O código entregue foi escrito para este projeto do zero e não inclui recursos, bibliotecas extraídas, código descompilado, logos, textos ou imagens do APK de referência. Usar padrões públicos OBD2/ELM327; confirmar direitos/licenças de quaisquer recursos futuros.
